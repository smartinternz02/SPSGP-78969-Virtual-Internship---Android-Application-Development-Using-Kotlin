Create a Birthday Card app - Solution Code
==========================================

Solution code for the Android Basics in Kotlin: Create a Birthday Card app codelab.
Starter code for the Android Basics in Kotlin: Add a cake to your Birthday Card app codelab.

Introduction
------------
In this codelab, you will create an Android Birthday Card app that displays text, 
using the Layout Editor in Android Studio.

Pre-requisites
--------------

You need to know:
- How to create a new app in Android Studio. 
- How to run an app in the emulator or on your Android device.


Getting Started
---------------

1. Download and run the app.
